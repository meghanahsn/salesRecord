'''
Author: Meghana Hassan Sridhara 19483342

Pledge of Honour: I pledge by honour that this program is solely my own work

Description: This program is to  Complete program template by filling code in function body..
'''
from datetime import datetime

# This is a non-value-returning function that prints all records in a tabular format.
def print_all(records):
    print("Course ID       Name            Enrolments")
    print("-----------------------------------------------------------------")
    # formatting output for better presentation
    fmtemp = '{0:15}{1:20}{2:5d}'
    # read all contents in a list
    for rec in records:
        # create a variable for display list according to formatting template 
        row = fmtemp.format(rec[0], rec[1], rec[2])
        # display data based on formatting
        print(row)
    print("Done") 
    print("\n")
   
    
# This is a value-returning function that returns a list of records.
def getdata():
    # create  a variable to store list data
    course_list = []
    # insert a values into list
    course_list.append(['comp001','Fundamentals',135])
    course_list.append(['comp002','Intro Database',30])
    course_list.append(['comp003','Web Programming',24])
    # return a list content
    return course_list

# This is a non-value-returning function to calculate total and average score
def calc_average_enrolment(records):
    # create a variable and assign value 0
    total_score = 0
    # create a variable and assign value 0
    average_score = 0
    # create a variable and assign value 0
    count = 0
    # read all contents in a list
    for rec in records:
        # increment a count value by 1 based on traversing
        count += 1
        # calculate score
        total_score += rec[2]
        # Calculate Average value based on score
        average_score = total_score/count
    # Display formatted Total score with 2 decimal number
    print("Total Score: ", float('{0:.2f}'.format(total_score)))
    # Display formatted Average score with 2 decimal number
    print("Avreage Score: ",float('{0:.2f}'.format(average_score)))
    print("\n")

# This is a non-value-returning function to search data based on course id
def search_by_courseid(records):
    # create a variable and read from user for the Course ID value
    id = input('Enter an Course ID: ')# target value
    # create a variable and assign none value
    found_rec = None 
    # read all contents in a list
    for rec in records:
        # check whether course Id matches with user entered Id
        if id == rec[0]:
            # Assign a list value at index 0 to another variable
            found_rec = rec 
        # Check value exist in a variable
        if found_rec != None:
            # format output for better representation
            fmttemp = '{0:15}{1:20}{2:5d}'
            # create a variable for display list according to formatting template 
            search_row = fmttemp.format(found_rec[0],found_rec[1],found_rec[2])
            # display data based on formatting
            print(search_row)
            break
    else:
        # exit the loop 
        if found_rec == None:
            print("No match were found")
            print("Done")


def main():
    # create a variable and assign function returned value to variable
    data = getdata()
    # function caller to display all content present in a list 
    print_all(data)
    # function caller to calculate average
    calc_average_enrolment(data)
    # function caller to search by CourseId
    search_by_courseid(data)
    
# start execution of a program
main()    