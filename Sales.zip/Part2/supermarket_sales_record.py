'''
Author: Meghana Hassan Sridhara 19483342

Pledge of Honour: I pledge by honour that this program is solely my own work

Description: This program is to Process supermarket sale records. 

'''
from _datetime import datetime

# This is a value-returning function that returns a list of records.
def readdata(filename):
    # create a list will null value
    records = []
    # Open file in read mode
    with open(filename, "r") as readfile:
        # read all data stored in a file
        for line in readfile:
            # create a variable and assign data by spliting
            a_list = line.split(",")
            # create a variable and store string value 
            date_str = a_list[0]  
            # create a variable and convert date string to date object
            date_obj = datetime.strptime(date_str, '%d-%m-%Y')
            # create a variable and assign list of data
            rec = [ date_obj.date(), a_list[1], float(a_list[2]), int(a_list[3])] 
            # store data into list
            records.append(rec)
    # return a list content
    return records

# This is a non-value-returning function that prints all records in a tabular format.
def print_all_records(records):
    print("Date                Branch             Daily Sale           Transaction")
    print("---------------------------------------------------------------------------------")
    # formatting output for better presentation
    fmtemp = '{0:<20}{1:<20}{2:<20.2f}{3:<10d}'
    # read all contents in a list
    for rec in records:
        # create a variable and assign a value in list at index 0
        rec_date_obj = rec[0]
        # convert string to datetime object based on format
        rec_date_str = datetime.strftime(rec_date_obj,'%d-%m-%Y')
        # create a variable for display list according to formatting template 
        row = fmtemp.format(rec_date_str,rec[1],rec[2],rec[3])
        # display data based on formatting
        print(row)


# This is a non-value-returning function that prints all records on user input date.        
def query_branch_sales(records):
    # create a variable and read from user for the Course ID value
    branch = input("Enter Branch Name: ")
    # create a list variable with null value
    sales_rec = []
    total_sale= 0
    average_sale = 0
    total_transaction = 0
    average_transaction = 0
    # target value
    found_rec = None 
    # read all contents in a list
    for rec in records:
        # target value matched
        if branch.lower() == rec[1].lower():
            # assign matched data to variable
            found_rec = rec 
            # store matched data into list
            sales_rec.append(found_rec)
    #break # exit the loop
    if found_rec == None:
        # display unsuccessful message
        print("Total sale by",branch,total_sale)
        print("Average sale by",branch,average_sale)
        print("Total Transaction by",branch,total_transaction)
        print("Average number of transactions per day by",branch,int(average_transaction))       
    else:
        count_sale = 0
        # read all contents in a list
        for i in sales_rec:
            # increment a value for every successful iteration
            count_sale += 1
            # sum data in daily sale 
            total_sale += i[2]
            # calculate average
            average_sale = total_sale/count_sale
            # sum data in transaction
            total_transaction += i[3]
            # calculate average transaction
            average_transaction = total_transaction/count_sale
        # display calculated values
        print("Total sale by",branch,total_sale)
        print("Average sale by",branch,average_sale)
        print("Total Transaction by",branch,total_transaction)
        print("Average number of transactions per day by",branch,int(average_transaction)) 
        

# This is a non-value-returning function that prints all records on user input date.                    
def query_record_by_date(records):  
    # formatting output for better presentation
    temp = '{0:<15}{1:<15}{2:<15.02f}{3:<15d}'
    rec_date = 0
    # create a variable and read from user for the date value
    datestr = input('Enter a date(dd mm yyyy): ')
    # create a variable and convert string to object
    dateobj = datetime.strptime(datestr, '%d %m %Y')
    # create a variable and convert objevt to string on specified format
    date_str = dateobj.strftime('%d-%m-%Y')
    date_found = None
    
    # read all contents in a list
    for rec in records:
        # create a variable and convert objevt to string on specified format
        rec_date = datetime.strftime(rec[0],'%d-%m-%Y')
        # check based on user date
        if date_str == rec_date:
            # assign selected list data to a variable
            date_found = rec
    # exit the loop
    if date_found == None:
        print('No record was returned from the search:', datestr)
    else:
        # convert object data into string based on specified format
        dstr = datetime.strftime(date_found[0], '%d/%m/%Y')
        # calculate based on daily sale and total transaction
        avt = date_found[2]/date_found[3]
        # display data on formatted output
        print(temp.format(dstr, date_found[1],date_found[2],date_found[3]))
        print("AVT for the day",round(avt,2))


# This is a non-value-returning function that prints all records on user input date.        
def query_period_sales(records):
    # formatting output for better presentation
    temp = '${0:<15.02f}'
    sale_transaction_date = 0
    # create a variable and read from user for the start date value
    d1 = input('Enter start date(dd mm yyyy): ')
    # create a variable and convert string to object
    date_obj_start = datetime.strptime(d1, '%d %m %Y')
    # create a variable and assign data in date data type
    date_start = datetime.date(date_obj_start)
    # create a variable and read from user for the end date value
    d2 = input('Enter end date(dd mm yyyy): ')
    # create a variable and convert string to object
    date_obj_end = datetime.strptime(d2, '%d %m %Y')
    # create a variable and assign data in date data type
    date_end = datetime.date(date_obj_end)
    
    matching = False
    # read all contents in a list
    for rec in records:
        # check for duration to display data
        if (rec[0] >= date_start) and (rec[0] <= date_end):
            # assign selected list data
            sale_transaction_date += rec[2]
            # values True is assigned
            matching = True
    # display transaction data
    print("Daily Transaction from",date_start,"till",date_end,"is ",temp.format(sale_transaction_date))
    
    # display unsuccessful message        
    if matching == False:
        print('No matching was found during the search')
            

# This is a non-value-returning function to take backup of file.        
def writedata(filename, records):
    # open file in write mode
    with open(filename, "w") as writefile:
        # read all contents in a list
        for rec in records:
            # convert date object into string value
            dstr = datetime.strftime(rec[0], '%d/%m/%Y')
            # create variable and assign value
            Branch = rec[1]
            # create variable and convert data into string type
            daily_sale = str(rec[2])
            transaction = str(rec[3])
            # individual data in list is assigned 
            line = ",".join([dstr, Branch,daily_sale,transaction])
            # write data into file
            writefile.write(line + "\n")

def main():
    # create a variable and assign function returned value to variable
    records = readdata('data.txt')
    # function caller to display all content present in a list 
    print_all_records(records)
    # function caller to display selected transaction in a list 
    query_branch_sales(records)
    # function caller to display record based on date in a list 
    query_record_by_date(records)
    # function caller to display record on mentioned duration 
    query_period_sales(records)
    # function caller to write list of data into file
    writedata('backup.txt', records)
    
# start execution of a program 
main()