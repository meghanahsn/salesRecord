'''
Author: Meghana Hassan Sridhara 19483342

Pledge of Honour: I pledge by honour that this program is solely my own work

Description: This program is to process student grades using loops and lists. .
'''
numberOfGrades = int(input("How many grades you want to enter? "))
grade_list = []
countIndex = []
total_score = 0
average_grade = 0
while numberOfGrades <= 1:
    print("Invalid. Must be greater than 1. Try again")
    numberOfGrades = int(input("How many grades you want to enter? "))
else:
    while numberOfGrades > 1:
        for i in range(numberOfGrades):
            enterGrades = int(input("Enter Grade"))
            grade_list.append(enterGrades)
            total_score += enterGrades
            average_grade = total_score/numberOfGrades
            
        #print(grade_list)
        fmtemp = '{0:<5d}{1:8d}'
        print("Display all grades")
        print("No         Grades")
        print("----------------------------------")
        count = 0
        for rec in grade_list:
            count = count + 1
            row = fmtemp.format(count,rec)
            print(row) 
        print("\nTotal score",total_score)
        print("Average Grade",round(average_grade,2))
        break